Gracias por utilizar ImageToStl. Junto con esta nota encontrará sus archivos convertidos.

Visite ImageToStl en https://imagetostl.com para obtener más herramientas gratuitas de conversión de archivos y visualización en línea.